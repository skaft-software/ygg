Ygg fixture release
